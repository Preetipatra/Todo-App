﻿using log4net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using static AngularApp1.Data.ApplicationDbContext;
using System.Reflection.Metadata;
using System.Security.Claims;
using System.Reflection;
using AngularApp1.Models;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Security.Cryptography;
using IHostingEnvironment = Microsoft.Extensions.Hosting.IHostingEnvironment;

namespace AngularApp1.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {

        private static readonly ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private readonly UserManager<User> _userManager;
        private readonly RoleManager<Role> _roleManager;
        private readonly SignInManager<User> _signInManager;
        private readonly IConfiguration _configuration;
        private readonly IHostingEnvironment _hostingEnvironment;

        public AccountController(IHostingEnvironment hostingEnvironment, IConfiguration configuration,
        UserManager<User> userManager, SignInManager<User> signInManager, RoleManager<Role> roleManager)
        {
            _hostingEnvironment = hostingEnvironment;
            _userManager = userManager;
            _signInManager = signInManager;
            _roleManager = roleManager;
            _configuration = configuration;


        }

        #region Login
        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginViewModel loginViewModeln)
        {
            try
            {
                User user = await _userManager.FindByNameAsync(loginViewModeln.Username);
                if (user == null)
                {
                    user = await _userManager.FindByEmailAsync(loginViewModeln.Username);
                }

                if (user == null)
                    return BadRequest("Invalid login user or password.");

                if (!user.Status)
                    return BadRequest("Your account has blocked. Please contact administrator.");

                var result = await _signInManager.CheckPasswordSignInAsync(user, loginViewModeln.Password, false);

                if (!result.Succeeded)
                {
                    return BadRequest("Invalid login user or password.");
                }

                IList<string> roles = await _userManager.GetRolesAsync(user);

                if (roles == null)
                {
                    return BadRequest("Role is not permissible");
                }

                List<Claim> claimsMain = new List<Claim>();
                Role userRole;
                IList<Claim> claimList;
                foreach (string role in roles)
                {
                    userRole = _roleManager.FindByNameAsync(role).Result;
                    if (userRole != null)
                    {
                        claimList = _roleManager.GetClaimsAsync(userRole).Result;
                        foreach (Claim claim in claimList)
                        {
                            if (!claimsMain.Contains(claim))
                            {
                                claimsMain.Add(claim);
                            }
                        }
                    }
                }
                claimList = CreateClaim(user, roles[0], claimsMain);
                string token = CreateToken(claimList);
                string refreshToken = CreateRefreshToken();
                user.RefreshToken = refreshToken;
                user.RefreshTokenExpiry = DateTime.Now.AddDays(7);
                await _userManager.UpdateAsync(user);
                return Ok(new
                {
                    accessToken = token,
                    refreshToken = refreshToken,
                    user = new
                    {
                        userId = user.Id,
                        fullName = user.FullName,
                        email = user.Email,
                        phoneNumber = user.PhoneNumber
                    }
                });
            }
            catch (Exception ex)
            {
                log.Error(ex);
                return BadRequest("Fiaid to ligin");
            }
        }
        #endregion

        #region Create Claim
        private IList<Claim> CreateClaim(User user, string role, IList<Claim> claims)
        {
            Claim clmID = new Claim(ClaimTypes.NameIdentifier, user.Id.ToString());
            Claim clmRole = new Claim(ClaimTypes.Role, role);
            Claim clmUserName = new Claim("Username", user.UserName);
            Claim clmJti = new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString());

            claims.Add(clmID);
            claims.Add(clmRole);
            claims.Add(clmUserName);
            claims.Add(clmJti);
            return claims;
        }
        #endregion

        #region Token
        private string CreateToken(IEnumerable<Claim> claims)
        {
            var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Token:Key"]));
            var signinCredentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha512);
            var tokenHandler = new JwtSecurityTokenHandler();
            var token = new JwtSecurityToken
            (
                issuer: _configuration["Token:Issuer"],
                audience: _configuration["Token:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddDays(2),
                notBefore: DateTime.UtcNow,
                signingCredentials: signinCredentials
            );

            var tokenString = tokenHandler.WriteToken(token);
            return tokenString;
        }
        #endregion

        #region CreateRefreshToken
        private string CreateRefreshToken()
        {
            var randomNumber = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomNumber);
                return Convert.ToBase64String(randomNumber);
            }
        }
        #endregion

    }
}
