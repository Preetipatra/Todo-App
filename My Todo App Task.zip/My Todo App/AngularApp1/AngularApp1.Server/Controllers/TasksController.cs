﻿using log4net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using log4net;
using AngularApp1.Data;
using System.Reflection;
using Microsoft.EntityFrameworkCore;
using AngularApp1.Entities;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;

namespace AngularApp1.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class TasksController : ControllerBase
    {
        private static readonly ILog Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private readonly ApplicationDbContext _Db;

        public TasksController(ApplicationDbContext Db)
        {
            _Db = Db;
        }

        [HttpGet()]
        public async Task<IActionResult> GetList()
        {
            try
            {
                using (var db = _Db)
                {
                   return Ok(await db.TASKS.ToListAsync());
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex);
                return BadRequest("Fail to get data.");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                using (var db = _Db)
                {
                   return Ok(await db.TASKS.Where(w=>w.Id == id).FirstOrDefaultAsync());
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex);
                return BadRequest("Fail to delete data.");
            }
        }


        [HttpPost]
        public async Task<IActionResult> AddTask(TASKS vm)
        {
            try
            {
                using (var db = _Db)
                {
                    TASKS entity = new TASKS();
                    entity.Title = vm.Title;
                    entity.Description = vm.Description;
                    entity.Completed = vm.Completed;
                    db.TASKS.Add(entity);
                    _ = await db.SaveChangesAsync();
                    return Ok(entity.Id);
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex);
                return BadRequest("Fail to save details.");
            }
        }


        [HttpPut]
        public async Task<IActionResult> Editask(TASKS vm)
        {
            try
            {
                using (var db = _Db)
                {
                    TASKS entity = db.TASKS.Find(vm.Id); ;
                    entity.Title = vm.Title;
                    entity.Description = vm.Description;
                    entity.Completed = vm.Completed;
                    db.TASKS.Update(entity);
                    _ = await db.SaveChangesAsync();
                    return Ok(entity.Id);
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex);
                return BadRequest("Fail to save details.");
            }
        }



        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                using (var db = _Db)
                {
                    TASKS entity = await db.TASKS.FindAsync(id);
                    if (entity != null)
                    {

                        db.TASKS.Remove(entity);
                        _ = await db.SaveChangesAsync();
                        return Ok(entity.Id);
                    }
                    else
                    {
                        return BadRequest("No record found to delete");
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex);
                return BadRequest("Fail to delete data.");
            }
        }

    }
}
