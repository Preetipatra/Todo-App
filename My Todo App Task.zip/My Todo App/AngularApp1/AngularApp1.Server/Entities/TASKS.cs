﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace AngularApp1.Entities
{
    [Table("TASKS")]
    public class TASKS
    {
        [Key]
        public int Id { get; set; }
        [StringLength(50)]
        public string Title { get; set; }

        [StringLength(100)]
        public string Description { get; set; }

        public bool Completed { get; set; }



    }
}
