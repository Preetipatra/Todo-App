﻿using System.ComponentModel.DataAnnotations;

namespace  AngularApp1.Models
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Email or Mobile number is required.")]
        [MaxLength(256)]
        public string Username { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        public string Password { get; set; }
    }

    public class AuthenticationConfiguration
    {
        public string AccessTokenSecret { get; set; }
        public double AccessTokenExpirationMinutes { get; set; }
        public string Issuer { get; set; }
        public string Audience { get; set; }
        public string RefreshTokenSecret { get; set; }
        public double RefreshTokenExpirationMinutes { get; set; }
    }

    public class Config
    {
        public static string DefaultConnectionString { get; set; }
    }

}
