﻿using log4net;
using Microsoft.AspNetCore.Identity;
using System.Reflection;
using static AngularApp1.Data.ApplicationDbContext;

namespace SkillTrialCore6.Data
{
    public class IdentityDataInitializer
    {
        private static readonly ILog Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        public class InitUser : User
        {
            public string Password { get; set; }
            public string Role { get; set; }

        }
        public static void SeedData(IServiceProvider services)
        {
            List<Role> roleList = new List<Role>();

            roleList.Add(new Role { Name = "Admin"});

            List<InitUser> userList = new List<InitUser>();
            userList.Add(new InitUser { Role = "Admin", FullName = "Administrator", UserName = "admin", Email = "info@task.com", Password = "Asdfg@12#",RefreshToken= "null" });

            CreateRoles(roleList, services);
            CreateUsers(userList, services);

        }
        public static void CreateRoles(List<Role> roleList, IServiceProvider serviceProvider)
        {
            // call karu?
            var roleManager = serviceProvider.GetService<RoleManager<Role>>();

            foreach (Role role in roleList)
            {
                if (!roleManager.RoleExistsAsync(role.Name).Result)
                {
                    var result = roleManager.CreateAsync(role).Result;
                }
            }

            var userManager = serviceProvider.GetService<UserManager<IdentityUser>>();

        }

        public static void CreateUsers(List<InitUser> userList, IServiceProvider serviceProvider)
        {
            var userManager = serviceProvider.GetService<UserManager<User>>();
            User user = new User();
            IdentityResult identityResult;
            foreach (InitUser _user in userList)
            {
                try
                {
                    user = userManager.FindByNameAsync(_user.UserName).Result;
                    if (user == null)
                    {
                        user = new User
                        {
                            FullName = _user.FullName,
                            UserName = _user.UserName,
                            Email = _user.Email,
                            EmailConfirmed = true,
                            Status = true
                        };
                        identityResult = userManager.CreateAsync(user, _user.Password).Result;
                        if (identityResult.Succeeded)
                        {
                            identityResult = userManager.AddToRoleAsync(user, _user.Role.ToLower()).Result;
                            if (!identityResult.Succeeded)
                            { Log.Error("fail to assign role to user."); }
                        }
                        else
                            Log.Error("fail to create user.");
                    }

                }
                catch (Exception ex)
                {
                    Log.Error("Create seed user error.");
                    Log.Error(ex);
                }
            }
        }
    }
}


