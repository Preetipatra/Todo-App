﻿//using Microsoft.EntityFrameworkCore;
//using AngularApp1.Entities;

//namespace AngularApp1.Data
//{
//    public class ApplicationDbContext
//    {
//        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
//           : base(options)
//        {
//        }
//        public virtual DbSet<TASKS> TASKS { get; set; }



//    }
//}

using Microsoft.EntityFrameworkCore;
using AngularApp1.Entities;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using static AngularApp1.Data.ApplicationDbContext;

namespace AngularApp1.Data
{
    public class ApplicationDbContext : IdentityDbContext<User, Role, int>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<TASKS> TASKS { get; set; }

        // Other DbSet properties can be added here for additional entities

        // Optionally, you can override the OnModelCreating method
        // to configure the model if needed

        public class User : IdentityUser<int>
        {
            [MaxLength(60)]
            public string FullName { get; set; }
            public string RefreshToken { get; set; }
            public DateTime RefreshTokenExpiry { get; set; }
            public bool Status { get; set; }
        }

        public class Role : IdentityRole<int>
        {
        }

    }
}
