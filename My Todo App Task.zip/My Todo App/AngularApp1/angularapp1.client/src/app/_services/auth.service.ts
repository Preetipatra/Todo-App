import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from "rxjs/operators";

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private apiUrl = 'http://localhost:5190/api/'; // replace with your API URL

  constructor(private http: HttpClient) { }

  header() {
    return new HttpHeaders({
      'Content-Type': 'application/json',
    });
  }

  login(userdata: any): Observable<any> {
    const body = JSON.stringify(userdata);
    return this.http.post(this.apiUrl + 'Account/Login', body, {
      headers: this.header(),
    })
      .pipe(
        map((response: any) => {
          if (response) {
            console.log("response", response)
            // this.authService.setUserName(response.userName);
            this.setAccessToken(response.accessToken);
            this.setRefreshToken(response.refreshToken);
          }
        })
      );
  }

  setAccessToken(token: any) {
    localStorage.setItem("AccessToken", token);
  }

  // getAccessToken(): any {
  //   let token = "";
  //   if (localStorage.getItem("AccessToken")) {
  //     token = localStorage.getItem("AccessToken");
  //   }
  //   return token;
  // }

  setRefreshToken(token: any) {
    localStorage.setItem('refreshToken', token);
  }

  // getRefreshToken(): any {
  //   let token = '';
  //   if (localStorage.getItem('refreshToken')) {
  //     token = localStorage.getItem('refreshToken');
  //   }
  //   return token;
  // }


  getRefreshToken(): string {
    let token = "";
    const refreshToken = localStorage.getItem("refreshToken");
    if (refreshToken !== null) {
      token = refreshToken;
    }
    return token;
  }


  getAccessToken(): string {
    let token = "";
    const accessToken = localStorage.getItem("AccessToken");
    if (accessToken !== null) {
      token = accessToken;

    }
    console.log(token, "token")
    return token;
  }


}