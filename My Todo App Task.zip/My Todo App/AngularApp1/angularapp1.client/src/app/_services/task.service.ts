import { Injectable } from '@angular/core';
import { HttpClient ,HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import {AuthService}  from './auth.service'

@Injectable({
  providedIn: 'root'
})
export class TaskService {

  private apiUrl = 'http://localhost:5190/api/Tasks'; // replace with your API URL
  public headers: HttpHeaders;

  constructor(private http: HttpClient,private authService: AuthService) {
    this.headers = new HttpHeaders({
      "Content-Type": "application/json",
      Authorization: "Bearer " + this.authService.getAccessToken(),
      // Lang: this.authService.getLanguage(),
    });

   }


 
 

  getData(): Observable<any> {
    return this.http.get(this.apiUrl,{
      headers: this.headers,
    });
  }

  postData(data: any): Observable<any> {
    return this.http.post(this.apiUrl, data,{
      headers: this.headers,
    });
  }

  putData(data: any): Observable<any> {
    return this.http.put(this.apiUrl, data,{
      headers: this.headers,
    });
  }

  deleteData(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`,{
      headers: this.headers,
    });
  }

  getTaskById(id: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/${id}`,{
      headers: this.headers,
    });
  }

}