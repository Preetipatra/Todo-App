import { Component } from "@angular/core";
import { Validators, FormGroup, FormControl } from "@angular/forms";
import { Router } from "@angular/router";
import { AuthService } from "../_services/auth.service"
import { ToastrService } from "ngx-toastr";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  submitted = false;
  isLoginFailed = false;

  showPassword = false;
  show_eye = false;


  loginForm = new FormGroup({
    username: new FormControl(null, [Validators.required]),
    password: new FormControl(null, [Validators.required]),
    rememberMe: new FormControl(true),
  });

  constructor(
    private router: Router,
    private authService: AuthService,
    private toastr: ToastrService
  ) { }

  get f() {
    return this.loginForm.controls;
  }



  togglePassword(): void {
    this.showPassword = !this.showPassword;
    this.show_eye = !this.show_eye;
  }


  onSubmit() {
    this.submitted = true;
    if (this.loginForm.invalid) {
      return;
    } else {
      const loginData = this.loginForm.value;
      this.authService.login(loginData).subscribe(
        (result) => {
          this.toastr.success("Login Success! Redirect to Dashboard... ");
          this.router.navigate(["/task"]);
        },
        (error) => {
          this.toastr.error("Failrd to login");
        }
      );
    }
  }

}
