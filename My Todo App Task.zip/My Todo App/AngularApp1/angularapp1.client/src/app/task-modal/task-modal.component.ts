import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { NgbActiveModal } from "@ng-bootstrap/ng-bootstrap";
import { ToastrService } from "ngx-toastr";
import { Task } from "../_models/task"
import { TaskService } from "../_services/task.service"


@Component({
  selector: 'app-task-modal',
  templateUrl: './task-modal.component.html',
  styleUrl: './task-modal.component.css'
})
export class TaskModalComponent {
  @Input() id!: number;
  @Output() onTask_Emit: EventEmitter<boolean> = new EventEmitter();

  submitted = false;
  formAddEdit!: FormGroup;

  constructor(
    public activeModal: NgbActiveModal,
    private formBuilder: FormBuilder,
    public toastr: ToastrService,
    public taskService: TaskService
  ) { }


  ngOnInit(): void {
    this.formAddEdit = this.formBuilder.group({
      title: ["", Validators.compose([Validators.required])],
      description: ["", Validators.compose([Validators.required])],
      completed: [false],
    });

    if (this.id > 0) {
      this.getTaskById()
    }

  }

  get f() {
    return this.formAddEdit.controls;
  }


  getTaskById() {
    this.taskService.getTaskById(this.id).subscribe(
      (result) => {
        if (result) {
          this.formAddEdit.patchValue(result);
        }
      },
      (error) => {
        this.toastr.error(error, "failed to get task list");
      }
    );
  }

  onSubmit_Form() {
    this.submitted = true;
    if (this.formAddEdit.invalid) {
      this.toastr.warning("Enter valid form details.");
      return;
    }
    const Data = this.formAddEdit.value as Task;
    Data.id = this.id ? this.id : 0;
    Data.title = this.formAddEdit.get('title')?.value
    Data.description = this.formAddEdit.get('description')?.value
    Data.completed = this.formAddEdit.get('completed')?.value
    if (this.id > 0) {
      this.taskService.putData(Data).subscribe(
        (result) => {
          if (result && result > 0) {
            this.toastr.success("Task edited successfull");
            this.onTask_Emit.emit(result);
            this.activeModal.close();
          } else {
            this.toastr.error("Something went wrong");
          }
        },
        (error) => {
          this.toastr.error(error);
        }
      );
    } else {
      this.taskService.postData(Data).subscribe(
        (result) => {
          if (result && result > 0) {
            this.toastr.success("Task add successfull");
            this.onTask_Emit.emit(result);
            this.activeModal.close();
          } else {
            this.toastr.error("Something went wrong");
          }
        },
        (error) => {
          this.toastr.error(error);
        }
      );
    }

  }

}
