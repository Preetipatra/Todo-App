import { Component, OnInit } from '@angular/core';
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { TaskService } from "../_services/task.service"
import { TaskModalComponent } from "../task-modal/task-modal.component";
import { ToastrService } from "ngx-toastr";
import swal from "sweetalert2";

@Component({
  selector: 'app-task-table',
  templateUrl: './task-table.component.html',
  styleUrl: './task-table.component.css'
})
export class TaskTableComponent {

  tasks : any[] =[]

  constructor( private modalService: NgbModal,
    private taskService:TaskService,
    private toastr :ToastrService
  ) {}

  ngOnInit(): void {
    this.getTaskList();
  }

  getTaskList() {
    this.taskService.getData().subscribe(
      (result) => {
        if (result) {
          this.tasks = result;
        }
      },
      (error) => {
        this.toastr.error(error, "Failed to get data");
      }
    );
  }


  onClick_Delete(id: any) {
    swal
      .fire({
        title: "Are you sure?",
        text: "You will not be able to revert this!", //Are you sure you want to delete?
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes, delete it!",
        customClass: {
          confirmButton: "btn btn-danger mr-2 mx-2",
          cancelButton: "btn btn-secondary",
        },
        buttonsStyling: false,
      })
      .then((res) => {
        if (res.value) {
          this.taskService.deleteData(id).subscribe(
            (result) => {
              if (result) {
                this.getTaskList();
              }
            },
            (error) => {
              console.log(error)
            }
          );
        }
      });
  }
  

  onAddEdit(id: number) {
    const modalRef = this.modalService.open(TaskModalComponent, {
      centered: true,
      backdrop: "static",
    });
    modalRef.componentInstance.id = id;
    modalRef.componentInstance.onTask_Emit.subscribe((data:any) => {
      if (data != null) {
        this.getTaskList();
      }
    });
  }

}
